; ==========================================================================
; WAR IN MIDDLE EARTH - EL CARTUCHO, MONTADO CON SOLO PASMO
; ==========================================================================
; Generado por tools/haz_rom.py --kit. Monta los 64 KB de la ROM a partir
; de los binarios de bin/ y del nombres.bin que deja la primera pasada.
; Lo unico que se edita a mano es src/nombres.asm; aqui no hay nada que
; tocar salvo que cambie la disposicion de la ROM, y eso lo decide Python.
;
; Las direcciones de las rutinas del parche llegan por simbolo desde
; nombres.sym, asi que los parches del juego siguen apuntando bien aunque
; la rutina se mueva.
; ==========================================================================

                include "nombres.sym"   ; lo que deja la primera pasada de pasmo

                org 00000h
                incbin "bin/cabeza.bin"         ; cabecera AB, arranque y stub con el plan
                defs 00800h-$,0FFh              ; lo que sobra hasta los datos, a 0xFF

; Los datos: la pantalla de carga comprimida, los tres bloques del juego
; -ya con los parches que no dependen del parche nuevo- y el mapa dibujado.
                incbin "bin/datos.bin"

; El hueco del ultimo banco: el reproductor PT3, el modulo, el puente y la
; rutina de las pantallas finales. Detras, el bloque que se recompila.
                org 0CE3Ah
                incbin "bin/hueco.bin"
NOMBRES_INI:
                incbin "nombres.bin"
NOMBRES_FIN_ROM:
NOMBRES_LEN:    equ NOMBRES_FIN_ROM-NOMBRES_INI

; Y la ROM se rellena hasta los 64 KB, como la deja Python.
                defs 010000h-$,0FFh

; --------------------------------------------------------------------------
; La longitud de la copia que el plan hace del bloque de nombres. Es el
; unico numero del plan que depende de lo que se acaba de ensamblar, asi
; que se escribe aqui encima en vez de dejarlo clavado en plan.inc.
; --------------------------------------------------------------------------
                org 003FCh
                defw NOMBRES_LEN

; --------------------------------------------------------------------------
; LOS PARCHES DEL JUEGO que llaman al parche nuevo. `org` retrocede sobre
; lo ya emitido: pasmo lo permite, y asi no hay que trocear los binarios.
; --------------------------------------------------------------------------

                ; 0x75A5: 0x75A5 salta a la rutina de la vista: 768 bytes a la VRAM en vez de 12.288
                org 0589Ch
                defb 0C3h
                defw CARACTERES_A_NOMBRES

                ; 0x044B: VRAM_A_ESCRIBIR pasa por el guardian, que devuelve la tabla de nombres a la identidad
                org 01D10h
                defb 0CDh
                defw GUARDIAN
                defb 000h

                ; 0x71A4: PINTA_LA_VISTA_DE_CERCA salta a MI_PINTA: cache del trozo y el cursor como sprite, fijo en el centro
                org 0549Bh
                defb 0C3h
                defw MI_PINTA

                ; 0x7225: el cursor se mueve una casilla cada 10 cuadros con la tecla pulsada
                org 0551Ch
                defb 0CDh
                defw MI_MUEVE

                ; 0x7758: en el menu de la casilla, arriba y abajo cambian de unidad por toque (MI_ELECCION)
                org 05A4Fh
                defb 0CDh
                defw MI_ELECCION

                ; 0x8DE4: la fuerza de la tropa se lee de la ficha de SU tipo en el terreno donde se pelea (MI_FUERZA), en vez de un byte cualquiera de 0x6D00
                org 070DBh
                defb 018h,008h,000h,000h,000h,000h,000h,000h,000h,000h,0CDh
                defw MI_FUERZA

                ; 0x90A6: ARMA_LOS_DOS_BANDOS apunta que el tablero esta sin subir (MI_ARMA)
                org 0739Dh
                defb 0CDh
                defw MI_ARMA

                ; 0x914B: al montar la batalla ya no aparece en el centro la unidad que se llevaba a mano en la anterior (MI_MONTA_BATALLA)
                org 07442h
                defb 0CDh
                defw MI_MONTA_BATALLA

                ; 0x8849: el tablero entero se sube SOLO la primera vuelta de cada batalla (MI_SUBE_TABLERO)
                org 06B40h
                defb 0CDh
                defw MI_SUBE_TABLERO

                ; 0x884C: fuera los 768 atributos de cada vuelta: 597.698 ciclos que nadie necesita
                org 06B43h
                defb 000h,000h,000h

                ; 0x8828: cada ficha que cambia se sube sola, dos celdas (MI_SUBE_FICHA)
                org 06B1Fh
                defb 0CDh
                defw MI_SUBE_FICHA

                ; 0x9160: la tecla F pone la batalla deprisa: se pinta una vuelta de cada 16 y el resto del bucle sigue igual (MI_TURBO)
                org 07457h
                defb 0CDh
                defw MI_TURBO

                ; 0x7F57: el bucle de partida sube ocho bytes de sprite en vez de un recuadro de 4x3 celdas
                org 0624Eh
                defb 0CDh
                defw MI_GUANTE

                ; 0x6575: MUEVE_EL_CURSOR deja de estampar el guante por software: ahora son dos sprites
                org 0486Ch
                defb 0C9h
