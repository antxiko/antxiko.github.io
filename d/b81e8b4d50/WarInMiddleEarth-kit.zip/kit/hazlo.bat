@echo off
rem Monta el cartucho con solo pasmo. Se edita src\nombres.asm y se corre esto.
setlocal
if "%PASMO%"=="" set PASMO=pasmo

echo [1/2] el parche: src\nombres.asm
%PASMO% --bin --equ NOMBRES_ORG=12880 --equ SOMBRA=0 --equ CUADROS=130 --equ PINTA_CADA=16 -I src src\nombres.asm nombres.bin nombres.sym
if errorlevel 1 goto :error

echo [2/2] la ROM: war_cart.asm
%PASMO% --bin -I . war_cart.asm WAR_UNIFICADA.ROM
if errorlevel 1 goto :error

echo Hecho: WAR_UNIFICADA.ROM
certutil -hashfile WAR_UNIFICADA.ROM SHA256
type bin\referencia.sha256
goto :eof
:error
echo FALLO
exit /b 1
