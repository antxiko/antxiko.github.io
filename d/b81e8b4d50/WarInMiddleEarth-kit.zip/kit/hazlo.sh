#!/bin/sh
# Monta el cartucho con solo pasmo. Se edita src/nombres.asm y se corre esto.
set -e
PASMO=${PASMO:-pasmo}
echo "[1/2] el parche: src/nombres.asm"
"$PASMO" --bin --equ NOMBRES_ORG=12880 --equ SOMBRA=0 --equ CUADROS=130 --equ PINTA_CADA=16 -I src src/nombres.asm nombres.bin nombres.sym
echo "[2/2] la ROM: war_cart.asm"
"$PASMO" --bin -I . war_cart.asm WAR_UNIFICADA.ROM
echo "Hecho: WAR_UNIFICADA.ROM"
sha256sum WAR_UNIFICADA.ROM 2>/dev/null || shasum -a 256 WAR_UNIFICADA.ROM
cat bin/referencia.sha256
